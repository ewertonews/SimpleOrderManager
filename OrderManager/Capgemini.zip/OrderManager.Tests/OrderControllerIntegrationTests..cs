using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderManager.Tests
{
    [TestClass]
    public class OrderControllerIntegrationTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
