using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderManager.Tests
{
    [TestClass]
    public class OrderControllerUnitTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
