﻿namespace OrderManager.Data
{
    public class OrderRecord
    {
        public int Id { get; set; }
        public string Status { get; set; }
    }
}
