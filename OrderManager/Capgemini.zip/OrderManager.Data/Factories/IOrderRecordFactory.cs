﻿namespace OrderManager.Data.Factories
{
    public interface IOrderRecordFactory
    {
        OrderRecord Create();
    }
}