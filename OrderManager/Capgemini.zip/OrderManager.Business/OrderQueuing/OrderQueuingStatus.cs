﻿namespace OrderManager.Business.OrderQueuing
{
    public enum OrderQueuingStatus
    {
        GENERALERROR,
        INVALIDORDER,
        SUCCESS
    }
}
