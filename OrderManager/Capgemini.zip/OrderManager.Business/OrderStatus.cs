﻿namespace OrderManager.Business
{
    public enum OrderStatus
    {
        Received = 1,
        InProgress,
        Completed,
        Canceled
    }
}
